aws cloudformation create-stack --stack-name SimpleWebApp `
--template-body file://"d:/SourceCode/Pluralsight_CloudFormation/Simple LB Webserver.yml" `
--parameters `
ParameterKey=KeyName,ParameterValue=SamplePSCourse `
ParameterKey=Subnets,ParameterValue=subnet-79cd781e\,subnet-c7ac1de9 `
ParameterKey=VPC,ParameterValue=vpc-c145bebb 
aws cloudformation describe-stack-events --stack-name SimpleWebApp
Clear-Host 
aws cloudformation describe-stacks --stack-name SimpleWebApp 
Clear-Host
aws cloudformation list-stacks --stack-status-filter CREATE_COMPLETE
aws cloudformation delete-stack --stack-name SimpleWebApp
aws cloudformation list-stacks --stack-status-filter CREATE_COMPLETE
aws cloudformation list-stacks --stack-status-filter DELETE_COMPLETE