aws s3 cp d:/SourceCode/PluralSight_CloudFormation/ElasticBeanstalk_Nodejs_Sample.template s3://cf-templates201905/
aws cloudformation create-stack --stack-name NodeEBSStackApp `
--template-url https://s3.amazonaws.com/cf-templates201905/ElasticBeanstalk_Nodejs_Sample.template `
--parameters `
ParameterKey=KeyName,ParameterValue=SamplePSCourse `
--capabilities CAPABILITY_IAM
aws cloudformation list-stacks --stack-status-filter CREATE_IN_PROGRESS
aws cloudformation list-stacks --stack-status-filter CREATE_COMPLETE
aws cloudformation describe-stacks --stack-name NodeEBSStackApp