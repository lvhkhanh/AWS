aws cloudformation create-stack --stack-name LAMPStackApp `
--template-body file://"d:/SourceCode/Pluralsight_CloudFormation/LAMPSTackTemplate.json" `
--parameters `
ParameterKey=VpcId,ParameterValue=vpc-c145bebb `
ParameterKey=Subnets,ParameterValue=subnet-79cd781e\,subnet-c7ac1de9 `
ParameterKey=KeyName,ParameterValue=SamplePSCourse `
ParameterKey=DBName,ParameterValue=SampleDB `
ParameterKey=DBUser,ParameterValue=dbuser1 `
ParameterKey=DBPassword,ParameterValue=AS12Ab12Aj 
aws cloudformation list-stacks --stack-status-filter CREATE_IN_PROGRESS
aws cloudformation list-stacks --stack-status-filter CREATE_COMPLETE
aws cloudformation describe-stacks --stack-name LAMPStackApp